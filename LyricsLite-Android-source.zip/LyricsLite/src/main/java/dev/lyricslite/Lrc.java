package dev.lyricslite;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Fetches time-synced (LRC) lyrics from LRCLIB and parses them. */
public final class Lrc {
    public record Line(long timeMs, String text) {}
    public record Result(String title, String artist, List<Line> lines) {}

    private static final Pattern TS = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");

    private Lrc() {}

    /** Free-text search ("artist - title"). Completes with null if nothing has synced lyrics. */
    public static CompletableFuture<Result> search(String query) {
        return fetch("https://lrclib.net/api/search?q=" + enc(query));
    }

    /** Search by exact track + artist, falling back to a free-text search. */
    public static CompletableFuture<Result> searchTrack(String track, String artist) {
        return fetch("https://lrclib.net/api/search?track_name=" + enc(track) + "&artist_name=" + enc(artist))
                .thenCompose(res -> res != null ? CompletableFuture.completedFuture(res) : search(artist + " " + track));
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static CompletableFuture<Result> fetch(String url) {
        return CompletableFuture.supplyAsync(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("User-Agent", "LyricsLite/1.1 (Minecraft Fabric mod)");
                int status = connection.getResponseCode();
                if (status != 200) throw new RuntimeException("LRCLIB returned HTTP " + status);
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder body = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                    JsonArray arr = JsonParser.parseString(body.toString()).getAsJsonArray();
                    for (JsonElement e : arr) {
                        JsonObject o = e.getAsJsonObject();
                        if (!o.has("syncedLyrics") || o.get("syncedLyrics").isJsonNull()) continue;
                        List<Line> lines = parse(o.get("syncedLyrics").getAsString());
                        if (lines.isEmpty()) continue;
                        return new Result(str(o, "trackName"), str(o, "artistName"), lines);
                    }
                    return null;
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static String str(JsonObject o, String key) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
    }

    static List<Line> parse(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String raw : lrc.split("\\R")) {
            Matcher m = TS.matcher(raw);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find(end) && m.start() == end) {
                long min = Long.parseLong(m.group(1));
                long sec = Long.parseLong(m.group(2));
                long ms = 0;
                String f = m.group(3);
                if (f != null) {
                    ms = Long.parseLong(f);
                    if (f.length() == 1) ms *= 100;
                    else if (f.length() == 2) ms *= 10;
                }
                times.add(min * 60_000 + sec * 1000 + ms);
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (long t : times) out.add(new Line(t, text));
        }
        out.sort(Comparator.comparingLong(Line::timeMs));
        return out;
    }
}
